"use client";

import { useState } from "react";
import { CornerFrame } from "@/components/ui/CornerFrame";

export default function AdminSettingsPage() {
  const [schoolName, setSchoolName] = useState("CSA – College of Saint Amateil");
  const [academicYear, setAcademicYear] = useState("2026-2027");
  const [enableNotifications, setEnableNotifications] = useState(true);
  const [autoEnrollment, setAutoEnrollment] = useState(false);
  const [saved, setSaved] = useState(false);

  return (
    <div className="space-y-6">
      <CornerFrame className="rounded-3xl border-2 border-gold bg-navy p-6 text-white shadow-xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold">Admin settings</p>
        <h1 className="mt-2 text-3xl font-bold">System configuration</h1>
        <p className="mt-3 text-sm leading-6 opacity-80">
          Configure school-level defaults and runtime options for your portal.
        </p>
      </CornerFrame>

      <CornerFrame className="rounded-3xl border border-base bg-surface p-6 shadow-card">
        <div className="space-y-6">
          <div className="grid gap-4 lg:grid-cols-2">
            <label className="space-y-2 text-sm font-semibold text-muted">
              School name
              <input
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
                className="w-full rounded-2xl border border-base bg-surface px-4 py-3 text-sm text-navy outline-none focus:border-gold"
              />
            </label>
            <label className="space-y-2 text-sm font-semibold text-muted">
              Academic year
              <input
                value={academicYear}
                onChange={(e) => setAcademicYear(e.target.value)}
                className="w-full rounded-2xl border border-base bg-surface px-4 py-3 text-sm text-navy outline-none focus:border-gold"
              />
            </label>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="flex items-center justify-between rounded-3xl border border-base bg-[var(--surface-strong)] px-4 py-4 text-sm font-semibold text-navy">
              <span>Enable admin notifications</span>
              <button
                type="button"
                onClick={() => setEnableNotifications((v) => !v)}
                className={`h-6 w-11 shrink-0 rounded-full transition ${enableNotifications ? "bg-gold" : "bg-surface"}`}
              >
                <span className={`block h-5 w-5 translate-y-0.5 rounded-full bg-white transition ${enableNotifications ? "translate-x-5" : "translate-x-0.5"}`} />
              </button>
            </div>
            <div className="flex items-center justify-between rounded-3xl border border-base bg-[var(--surface-strong)] px-4 py-4 text-sm font-semibold text-navy">
              <span>Auto enrollment review</span>
              <button
                type="button"
                onClick={() => setAutoEnrollment((v) => !v)}
                className={`h-6 w-11 shrink-0 rounded-full transition ${autoEnrollment ? "bg-gold" : "bg-surface"}`}
              >
                <span className={`block h-5 w-5 translate-y-0.5 rounded-full bg-white transition ${autoEnrollment ? "translate-x-5" : "translate-x-0.5"}`} />
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setSaved(true)}
            className="inline-flex items-center rounded-full bg-navy px-6 py-3 text-sm font-semibold text-white transition hover:bg-gold hover:text-navy"
          >
            Save settings
          </button>
          {saved ? <p className="text-sm text-emerald-600">Settings saved locally.</p> : null}
        </div>
      </CornerFrame>
    </div>
  );
}
